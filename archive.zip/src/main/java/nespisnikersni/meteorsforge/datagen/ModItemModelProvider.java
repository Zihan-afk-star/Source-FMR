package nespisnikersni.meteorsforge.datagen;

import nespisnikersni.meteorsforge.Meteorsforge;
import net.minecraft.data.PackOutput;
import net.minecraftforge.common.data.ExistingFileHelper;

public class ModItemModelProvider extends net.minecraftforge.client.model.generators.ItemModelProvider {
    public ModItemModelProvider(PackOutput out, ExistingFileHelper efh) {
        super(out, Meteorsforge.MODID, efh);
    }

    @Override
    protected void registerModels() {
        generatedArmor("frezarite");
        generatedArmor("kreknorite");
        generatedArmor("meteorite");

        generatedTools("frezarite", true, true, true, true, true);
        generatedTools("kreknorite", true, false, false, false, false);
        generatedTools("meteorite",  true, true, true, true, true);

        simpleGenerated("kreknorite_ingot");
        simpleGenerated("meteorite_ingot");
        simpleGenerated("meteorite_chip");
        simpleGenerated("kreknorite_chip");
        simpleGenerated("frezarite_ingot");
        simpleGenerated("frezarite_crystal");
        simpleGenerated("meteorite_egg");
        simpleGenerated("meteorite_ice_egg");
    }


    private void generatedArmor(String mat) {
        withExistingParent(mat + "_helmet", mcLoc("item/generated"))
                .texture("layer0", modLoc("item/" + mat + "_helmet"));
        withExistingParent(mat + "_chestplate", mcLoc("item/generated"))
                .texture("layer0", modLoc("item/" + mat + "_chestplate"));
        withExistingParent(mat + "_leggings", mcLoc("item/generated"))
                .texture("layer0", modLoc("item/" + mat + "_leggings"));
        withExistingParent(mat + "_boots", mcLoc("item/generated"))
                .texture("layer0", modLoc("item/" + mat + "_boots"));
    }

    private void generatedTools(String mat, boolean sword, boolean axe, boolean pickaxe, boolean shovel, boolean hoe) {
        if (sword)   handheld(mat + "_sword");
        if (axe)     handheld(mat + "_axe");
        if (pickaxe) handheld(mat + "_pickaxe");
        if (shovel)  handheld(mat + "_shovel");
        if (hoe)     handheld(mat + "_hoe");
    }

    private void handheld(String name) {
        withExistingParent(name, mcLoc("item/handheld"))
                .texture("layer0", modLoc("item/" + name));
    }

    private void simpleGenerated(String name) {
        withExistingParent(name, mcLoc("item/generated"))
                .texture("layer0", modLoc("item/" + name));
    }
}