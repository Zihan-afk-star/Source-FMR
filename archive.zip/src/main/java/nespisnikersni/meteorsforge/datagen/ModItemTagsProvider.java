package nespisnikersni.meteorsforge.datagen;

import nespisnikersni.meteorsforge.item.ModItems;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.ItemTagsProvider;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.data.ExistingFileHelper;

import java.util.concurrent.CompletableFuture;

public class ModItemTagsProvider extends ItemTagsProvider {
    public ModItemTagsProvider(PackOutput out,
                               CompletableFuture<HolderLookup.Provider> lookup,
                               CompletableFuture<TagLookup<Block>> blockTags,
                               String modid, ExistingFileHelper efh) {
        super(out, lookup, blockTags, modid, efh);
    }

    @Override
    protected void addTags(HolderLookup.Provider provider) {
        tag(ItemTags.TRIMMABLE_ARMOR).add(
            ModItems.FREZARITE_HELMET.get(),
            ModItems.FREZARITE_CHESTPLATE.get(),
            ModItems.FREZARITE_LEGGINGS.get(),
            ModItems.FREZARITE_BOOTS.get(),

            ModItems.KREKNORITE_HELMET.get(),
            ModItems.KREKNORITE_CHESTPLATE.get(),
            ModItems.KREKNORITE_LEGGINGS.get(),
            ModItems.KREKNORITE_BOOTS.get(),

            ModItems.METEORITE_HELMET.get(),
            ModItems.METEORITE_CHESTPLATE.get(),
            ModItems.METEORITE_LEGGINGS.get(),
            ModItems.METEORITE_BOOTS.get()
        );
    }
}