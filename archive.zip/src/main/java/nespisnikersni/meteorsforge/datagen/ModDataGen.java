package nespisnikersni.meteorsforge.datagen;

import nespisnikersni.meteorsforge.Meteorsforge;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.TagsProvider;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.data.event.GatherDataEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Collections;
import java.util.concurrent.CompletableFuture;

@Mod.EventBusSubscriber(modid = Meteorsforge.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModDataGen {
    @SubscribeEvent
    public static void gatherData(GatherDataEvent e) {
        DataGenerator gen = e.getGenerator();
        PackOutput out = gen.getPackOutput();
        ExistingFileHelper efh = e.getExistingFileHelper();
        CompletableFuture<HolderLookup.Provider> lookup = e.getLookupProvider();
         var blockTags = new ModBlockTagsProvider(out, lookup, Meteorsforge.MODID, efh);
        // CLIENT
        if (e.includeClient()) {
            gen.addProvider(true, new ModItemModelProvider(out, efh));
        }

        // SERVER
        if (e.includeServer()) {
            gen.addProvider(true, new ModItemTagsProvider(out, lookup, blockTags.contentsGetter(), Meteorsforge.MODID, efh));
        }

    }
}