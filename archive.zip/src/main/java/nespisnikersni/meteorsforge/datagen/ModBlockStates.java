package nespisnikersni.meteorsforge.datagen;

import nespisnikersni.meteorsforge.block.ModBlocks;
import net.minecraft.data.DataGenerator;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraftforge.client.model.generators.BlockStateProvider;
import net.minecraftforge.client.model.generators.ModelFile;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.registries.ForgeRegistries;

public class ModBlockStates extends BlockStateProvider {
    public static final String MODID = "meteorsforge";

    public ModBlockStates(DataGenerator gen, ExistingFileHelper ex) {
        super(gen.getPackOutput(), MODID, ex);
    }

    @Override
    protected void registerStatesAndModels() {

        cubeAll(ModBlocks.FREZARITE_BLOCK.get(),   tex("block/frezarite_block"));
        cubeAll(ModBlocks.KREKNORITE_BLOCK.get(),  tex("block/kreknorite_block"));
        cubeAll(ModBlocks.METEORITE_BLOCK.get(),   tex("block/meteorite_block"));
        cubeAll(ModBlocks.BLOCK_RED_GEM.get(),     tex("block/block_red_gem"));
        cubeAll(ModBlocks.FREZARITE_ORE.get(),     tex("block/frezarite_ore"));
        cubeAll(ModBlocks.METEOR_ORE.get(),        tex("block/meteor_ore"));
        cubeAll(ModBlocks.PROTECTED_LAND_TESTER.get(),        tex("block/protected_land_tester"));
        cubeAll(ModBlocks.PROTECTED_LAND_TESTER_ACTIVE.get(), tex("block/protected_land_tester_active"));
    }

    private ResourceLocation tex(String path) {
        return new ResourceLocation(MODID, path);
    }

    private void cubeAll(Block block, ResourceLocation texture) {
        var name = ForgeRegistries.BLOCKS.getKey(block).getPath();
        var model = models().cubeAll(name, texture);
        simpleBlock(block, model);
        simpleBlockItem(block, model);
    }
}