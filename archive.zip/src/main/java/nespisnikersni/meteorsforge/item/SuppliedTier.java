package nespisnikersni.meteorsforge.item;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.IntSupplier;
import java.util.function.Supplier;

public final class SuppliedTier implements Tier {
    private final IntSupplier level, uses, enchant;
    private final FloatSupplier speed;
    private final FloatSupplier attackBonus;
    private final Supplier<Ingredient> repair;

    public SuppliedTier(IntSupplier level, IntSupplier uses, FloatSupplier speed,
                        FloatSupplier attackBonus, IntSupplier enchant, Supplier<Ingredient> repair) {
        this.level = level;
        this.uses = uses;
        this.speed = speed;
        this.attackBonus = attackBonus;
        this.enchant = enchant;
        this.repair = repair;
    }

    @Override public int getUses() { return uses.getAsInt(); }
    @Override public float getSpeed() { return speed.getAsFloat(); }
    @Override public float getAttackDamageBonus() { return attackBonus.getAsFloat(); }
    @Override public int getLevel() { return level.getAsInt(); }
    @Override public int getEnchantmentValue() { return enchant.getAsInt(); }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }

    @FunctionalInterface public interface FloatSupplier { float getAsFloat(); }
}
