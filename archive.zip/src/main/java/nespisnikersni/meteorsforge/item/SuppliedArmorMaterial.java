package nespisnikersni.meteorsforge.item;

import nespisnikersni.meteorsforge.Meteorsforge;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.IntSupplier;
import java.util.function.Supplier;

public final class SuppliedArmorMaterial implements ArmorMaterial {
    private final String name;
    private final IntSupplier durabilityMul;
    private final IntSupplier[] slotProt;
    private final IntSupplier ench;
    private final Supplier<SoundEvent> equip;
    private final DoubleSupplier tough;
    private final DoubleSupplier kbres;
    private final Supplier<Ingredient> repair;

    private static final int[] HEALTH_PER_SLOT = {13, 15, 16, 11};

    public SuppliedArmorMaterial(
            String name,
            IntSupplier durabilityMul,
            IntSupplier[] slotProt,
            IntSupplier ench,
            Supplier<SoundEvent> equip,
            DoubleSupplier tough,
            DoubleSupplier kbres,
            Supplier<Ingredient> repair
    ) {
        this.name = name;
        this.durabilityMul = durabilityMul;
        this.slotProt = slotProt;
        this.ench = ench;
        this.equip = equip;
        this.tough = tough;
        this.kbres = kbres;
        this.repair = repair;
    }

    private static int idx(ArmorItem.Type t) {
        return switch (t) { case BOOTS -> 0; case LEGGINGS -> 1; case CHESTPLATE -> 2; case HELMET -> 3; };
    }

    @Override public int getDurabilityForType(ArmorItem.Type t) { return HEALTH_PER_SLOT[idx(t)] * durabilityMul.getAsInt(); }
    @Override public int getDefenseForType(ArmorItem.Type t)     { return slotProt[idx(t)].getAsInt(); }
    @Override public int getEnchantmentValue()                    { return ench.getAsInt(); }
    @Override public SoundEvent getEquipSound()                   { return equip.get(); }
    @Override public Ingredient getRepairIngredient()             { return repair.get(); }
    @Override public String getName()                             { return name; }
    @Override public float getToughness()                         { return (float) tough.getAsDouble(); }
    @Override public float getKnockbackResistance()               { return (float) kbres.getAsDouble(); }

    @FunctionalInterface public interface DoubleSupplier { double getAsDouble(); }
}