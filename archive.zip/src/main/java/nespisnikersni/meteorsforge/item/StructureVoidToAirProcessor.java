package nespisnikersni.meteorsforge.item;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessor;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessorType;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import org.jetbrains.annotations.Nullable;

public class StructureVoidToAirProcessor extends StructureProcessor {
    public static final StructureVoidToAirProcessor INSTANCE = new StructureVoidToAirProcessor();

    @Override
    @Nullable
    public StructureTemplate.StructureBlockInfo processBlock(
            LevelReader p_74416_,
            BlockPos p_74417_,
            BlockPos p_74418_,
            StructureTemplate.StructureBlockInfo p_74419_,
            StructureTemplate.StructureBlockInfo p_74420_,
            StructurePlaceSettings p_74421_
    ) {
        if (p_74420_ == null) return null;

        if (p_74420_.state().is(Blocks.STRUCTURE_VOID)) {
            return new StructureTemplate.StructureBlockInfo(
                    p_74420_.pos(),
                    Blocks.AIR.defaultBlockState(),
                    null
            );
        }

        // Иначе — без изменений
        return p_74420_;
    }


    @Override
    protected StructureProcessorType<?> getType() {
        return StructureProcessorType.BLOCK_IGNORE;
    }
}