package nespisnikersni.meteorsforge.item;

import nespisnikersni.meteorsforge.Config;
import nespisnikersni.meteorsforge.Meteorsforge;
import nespisnikersni.meteorsforge.config.KVConfig;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Meteorsforge.MODID);

    // ---------- helpers ----------
    private static SoundEvent sound(String id, String def) {
        ResourceLocation rl = new ResourceLocation(id != null ? id : def);
        SoundEvent se = ForgeRegistries.SOUND_EVENTS.getValue(rl);
        if (se == null) se = ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation(def));
        return se;
    }
    private static Ingredient repair(String id, String def) {
        ResourceLocation rl = new ResourceLocation(id != null ? id : def);
        Item it = ForgeRegistries.ITEMS.getValue(rl);
        if (it == null) it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(def));
        return Ingredient.of(it != null ? it : Items.AIR);
    }

    private static Ingredient ingredient(String id, String def) {
        var rl = new ResourceLocation(id != null ? id : def);
        var it = ForgeRegistries.ITEMS.getValue(rl);
        if (it == null) it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(def));
        return Ingredient.of(it != null ? it : Items.AIR);
    }

    private static IntSupplier[] protSuppliers(String baseKey, int[] def) {
        // читаем массив 4 значений на каждый вызов — просто и безопасно
        return new IntSupplier[]{
            () -> KVConfig.getIntArray4(baseKey + "protections", def)[0], // boots
            () -> KVConfig.getIntArray4(baseKey + "protections", def)[1], // leggings
            () -> KVConfig.getIntArray4(baseKey + "protections", def)[2], // chest
            () -> KVConfig.getIntArray4(baseKey + "protections", def)[3]  // helmet
        };
    }

    private static ArmorMaterial buildArmor(String matName, String baseKey,
                                            int defDurMult, int[] defProt, int defEnchant,
                                            String defSound, double defTough, double defKb,
                                            String defRepair) {
        return new SuppliedArmorMaterial(
            Meteorsforge.MODID + ":" + matName,
            () -> KVConfig.getInt(baseKey + "durabilityMultiplier", defDurMult),
            protSuppliers(baseKey, defProt),
            () -> KVConfig.getInt(baseKey + "enchantability", defEnchant),
            () -> sound(KVConfig.getString(baseKey + "equipSound", null), defSound),
            () -> KVConfig.getDouble(baseKey + "toughness", defTough),
            () -> KVConfig.getDouble(baseKey + "knockbackResist", defKb),
            () -> repair(KVConfig.getString(baseKey + "repairItem", null), defRepair)
        );
    }

    // ---------- materials from KV ----------
    private static final ArmorMaterial FREZARITE_MATERIAL = buildArmor(
        "frezarite", "armor.frezarite.",
        37, new int[]{3,6,8,3}, 15,
        "minecraft:item.armor.equip_netherite", 3.0, 0.10,
        "minecraft:diamond"
    );

    private static final ArmorMaterial KREKNORITE_MATERIAL = buildArmor(
        "kreknorite", "armor.kreknorite.",
        40, new int[]{4,7,9,4}, 18,
        "minecraft:item.armor.equip_diamond", 3.5, 0.15,
        "minecraft:netherite_ingot"
    );

    private static final ArmorMaterial METEORITE_MATERIAL = buildArmor(
        "meteorite", "armor.meteorite.",
        33, new int[]{3,6,8,3}, 20,
        "minecraft:item.armor.equip_iron", 2.5, 0.0,
        "minecraft:iron_ingot"
    );

    private static SuppliedTier tier(String key, int defUses, int defLevel, float defSpeed, float defAtk, int defEnch, String defRepairItem) {
        return new SuppliedTier(
                () -> KVConfig.getInt("tier."+key+".level", defLevel),
                () -> KVConfig.getInt("tier."+key+".uses", defUses),
                () -> (float) KVConfig.getDouble("tier."+key+".speed", defSpeed),
                () -> (float) KVConfig.getDouble("tier."+key+".attackBonus", defAtk),
                () -> KVConfig.getInt("tier."+key+".enchantability", defEnch),
                () -> ingredient(KVConfig.getString("tier."+key+".repairItem", null), defRepairItem)
        );
    }
    private static final Tier FREZARITE_TIER  = tier("frezarite", 2031, 4, 9.0f, 4.0f, 15, "minecraft:diamond");
    private static final Tier KREKNORITE_TIER = tier("kreknorite",2342, 4, 9.5f, 4.5f,18, "minecraft:netherite_ingot"); // если понадобятся инструменты
    private static final Tier METEORITE_TIER  = tier("meteorite", 1796, 3, 8.0f, 3.0f, 20, "minecraft:iron_ingot");


    // ---------- registration ----------
    public static final RegistryObject<Item> FREZARITE_HELMET     = ITEMS.register("frezarite_helmet",     () -> new ArmorItem(FREZARITE_MATERIAL, ArmorItem.Type.HELMET,     new Item.Properties()));
    public static final RegistryObject<Item> FREZARITE_CHESTPLATE = ITEMS.register("frezarite_chestplate", () -> new ArmorItem(FREZARITE_MATERIAL, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> FREZARITE_LEGGINGS   = ITEMS.register("frezarite_leggings",   () -> new ArmorItem(FREZARITE_MATERIAL, ArmorItem.Type.LEGGINGS,   new Item.Properties()));
    public static final RegistryObject<Item> FREZARITE_BOOTS      = ITEMS.register("frezarite_boots",      () -> new ArmorItem(FREZARITE_MATERIAL, ArmorItem.Type.BOOTS,      new Item.Properties()));

    public static final RegistryObject<Item> KREKNORITE_HELMET     = ITEMS.register("kreknorite_helmet",     () -> new ArmorItem(KREKNORITE_MATERIAL, ArmorItem.Type.HELMET,     new Item.Properties()));
    public static final RegistryObject<Item> KREKNORITE_CHESTPLATE = ITEMS.register("kreknorite_chestplate", () -> new ArmorItem(KREKNORITE_MATERIAL, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> KREKNORITE_LEGGINGS   = ITEMS.register("kreknorite_leggings",   () -> new ArmorItem(KREKNORITE_MATERIAL, ArmorItem.Type.LEGGINGS,   new Item.Properties()));
    public static final RegistryObject<Item> KREKNORITE_BOOTS      = ITEMS.register("kreknorite_boots",      () -> new ArmorItem(KREKNORITE_MATERIAL, ArmorItem.Type.BOOTS,      new Item.Properties()));

    public static final RegistryObject<Item> METEORITE_HELMET     = ITEMS.register("meteorite_helmet",     () -> new ArmorItem(METEORITE_MATERIAL, ArmorItem.Type.HELMET,     new Item.Properties()));
    public static final RegistryObject<Item> METEORITE_CHESTPLATE = ITEMS.register("meteorite_chestplate", () -> new ArmorItem(METEORITE_MATERIAL, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> METEORITE_LEGGINGS   = ITEMS.register("meteorite_leggings",   () -> new ArmorItem(METEORITE_MATERIAL, ArmorItem.Type.LEGGINGS,   new Item.Properties()));
    public static final RegistryObject<Item> METEORITE_BOOTS      = ITEMS.register("meteorite_boots",      () -> new ArmorItem(METEORITE_MATERIAL, ArmorItem.Type.BOOTS,      new Item.Properties()));


    public static final RegistryObject<Item> METEORITE_INGOT = ITEMS.register("meteorite_ingot", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> METEORITE_CHIP = ITEMS.register("meteorite_chip", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> KREKNORITE_INGOT = ITEMS.register("kreknorite_ingot", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> KREKNORITE_CHIP  = ITEMS.register("kreknorite_chip",  () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> FREZARITE_INGOT = ITEMS.register("frezarite_ingot", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FREZARITE_CRYSTAL  = ITEMS.register("frezarite_crystal",  () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> METEORITE_EGG  = ITEMS.register("meteorite_egg",  () -> new StructureSpawnEggItem(new Item.Properties(), "meteorite"));
    public static final RegistryObject<Item> METEORITE_ICE_EGG  = ITEMS.register("meteorite_ice_egg",  () -> new StructureSpawnEggItem(new Item.Properties(), "meteorite_ice"));

    public static final RegistryObject<Item> FREZARITE_SWORD   = ITEMS.register("frezarite_sword",   () -> new SwordItem(FREZARITE_TIER, 3, -2.4f, new Item.Properties()));
    public static final RegistryObject<Item> FREZARITE_AXE     = ITEMS.register("frezarite_axe",     () -> new AxeItem(FREZARITE_TIER,   5.0f, -3.0f, new Item.Properties()));
    public static final RegistryObject<Item> FREZARITE_PICKAXE = ITEMS.register("frezarite_pickaxe", () -> new PickaxeItem(FREZARITE_TIER,1, -2.8f, new Item.Properties()));
    public static final RegistryObject<Item> FREZARITE_SHOVEL  = ITEMS.register("frezarite_shovel",  () -> new ShovelItem(FREZARITE_TIER,1.5f, -3.0f, new Item.Properties()));
    public static final RegistryObject<Item> FREZARITE_HOE     = ITEMS.register("frezarite_hoe",     () -> new HoeItem(FREZARITE_TIER,   -1, -1.0f, new Item.Properties()));

    public static final RegistryObject<Item> KREKNORITE_SWORD  = ITEMS.register("kreknorite_sword",  () -> new SwordItem(KREKNORITE_TIER, 3, -2.4f, new Item.Properties()));

    public static final RegistryObject<Item> METEORITE_SWORD   = ITEMS.register("meteorite_sword",   () -> new SwordItem(METEORITE_TIER, 3, -2.4f, new Item.Properties()));
    public static final RegistryObject<Item> METEORITE_AXE     = ITEMS.register("meteorite_axe",     () -> new AxeItem(METEORITE_TIER,   5.0f, -3.0f, new Item.Properties()));
    public static final RegistryObject<Item> METEORITE_PICKAXE = ITEMS.register("meteorite_pickaxe", () -> new PickaxeItem(METEORITE_TIER,1, -2.8f, new Item.Properties()));
    public static final RegistryObject<Item> METEORITE_SHOVEL  = ITEMS.register("meteorite_shovel",  () -> new ShovelItem(METEORITE_TIER,1.5f, -3.0f, new Item.Properties()));
    public static final RegistryObject<Item> METEORITE_HOE     = ITEMS.register("meteorite_hoe",     () -> new HoeItem(METEORITE_TIER,   -1, -1.0f, new Item.Properties()));
}
