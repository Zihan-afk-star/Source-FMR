package nespisnikersni.meteorsforge.item;

import nespisnikersni.meteorsforge.Meteorsforge;
import nespisnikersni.meteorsforge.entity.MeteorEntity;
import nespisnikersni.meteorsforge.entity.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.templatesystem.BlockIgnoreProcessor;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;
public class StructureSpawnEggItem extends Item {
    private final String structure;

    public StructureSpawnEggItem(Properties properties, String structure) {
        super(properties);
        this.structure = structure;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!level.isClientSide) {
            BlockPos clicked = context.getClickedPos().above();

            Vec3 target = new Vec3(clicked.getX() + 0.5, clicked.getY(), clicked.getZ() + 0.5);

            double startY = Math.min(level.getMaxBuildHeight() - 5, target.y + 60);
            Vec3 start = new Vec3(target.x, startY, target.z);

            Vec3 vel = new Vec3(0, -1.2, 0);

            ResourceLocation structureId = new ResourceLocation(Meteorsforge.MODID, structure);

            MeteorEntity meteor = new MeteorEntity(ModEntities.METEOR.get(), level, start.x, start.y, start.z, vel, structureId);
            ((ServerLevel) level).addFreshEntity(meteor);

            context.getItemInHand().shrink(1);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}