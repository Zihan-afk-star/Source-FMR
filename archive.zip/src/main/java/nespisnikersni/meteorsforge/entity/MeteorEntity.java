package nespisnikersni.meteorsforge.entity;

import nespisnikersni.meteorsforge.Meteorsforge;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.templatesystem.*;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.entity.IEntityAdditionalSpawnData;
import net.minecraftforge.network.NetworkHooks;

import java.util.Objects;
import java.util.Optional;

public class MeteorEntity extends AbstractHurtingProjectile implements IEntityAdditionalSpawnData {

    public ResourceLocation structureId = null;

    public MeteorEntity(EntityType<? extends MeteorEntity> type, Level level) {
        super(type, level);
        this.noCulling = true;
        this.noPhysics = false;
    }

    public MeteorEntity(EntityType<? extends MeteorEntity> type, Level level, double x, double y, double z, Vec3 velocity, ResourceLocation structureId) {
        this(type, level);
        this.setPos(x, y, z);
        this.setDeltaMovement(velocity);
        this.structureId = structureId;
    }

    public void setStructureId(ResourceLocation id) { this.structureId = id; }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (level().isClientSide) return;

        BlockPos hitPos = (result instanceof BlockHitResult bhr)
                ? bhr.getBlockPos().above()
                : BlockPos.containing(result.getLocation());

        level().playSound(null, hitPos, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1.2f, 0.9f + level().getRandom().nextFloat() * 0.2f);
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(net.minecraft.core.particles.ParticleTypes.LARGE_SMOKE,
                    hitPos.getX() + 0.5, hitPos.getY() + 0.1, hitPos.getZ() + 0.5,
                    30, 0.6, 0.3, 0.6, 0.01);
        }
        float radius = 5.0F + level().getRandom().nextFloat() * 2.0F;
        level().explode(
                this,
                hitPos.getX() + 0.5,
                hitPos.getY() + 0.5,
                hitPos.getZ() + 0.5,
                radius,
                Level.ExplosionInteraction.BLOCK
        );

        if (structureId != null && level() instanceof ServerLevel serverLevel) {
            StructureTemplateManager manager = serverLevel.getStructureManager();
            Optional<StructureTemplate> templateOpt = manager.get(structureId);
            if (templateOpt.isPresent()) {
                StructureTemplate template = templateOpt.get();

                BlockPos placePos = hitPos.offset(-6, -7, -6);

                StructurePlaceSettings settings = new StructurePlaceSettings()
                        .setIgnoreEntities(false)
                        .setRotation(Rotation.NONE)
                        .setMirror(Mirror.NONE)
                        .addProcessor(BlockIgnoreProcessor.AIR);

                template.placeInWorld(serverLevel, placePos, placePos, settings, serverLevel.getRandom(), 2);
            } else {
                System.out.println("Структура не найдена: " + structureId);
            }
        }

        discard();
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            for (int i = 0; i < 4; i++) {
                double dx = getX() + (random.nextDouble() - 0.5) * 0.6;
                double dy = getY() + random.nextDouble() * 0.6;
                double dz = getZ() + (random.nextDouble() - 0.5) * 0.6;
                level().addParticle(net.minecraft.core.particles.ParticleTypes.FLAME, dx, dy, dz, 0, -0.02, 0);
                level().addParticle(net.minecraft.core.particles.ParticleTypes.SMOKE, dx, dy, dz, 0, 0, 0);
            }
        } else {
            Vec3 v = getDeltaMovement();
            setDeltaMovement(v.x, v.y - 0.05, v.z);

            double max = 2.5;
            setDeltaMovement(
                    Mth.clamp(getDeltaMovement().x, -max, max),
                    Math.max(getDeltaMovement().y, -max),
                    Mth.clamp(getDeltaMovement().z, -max, max)
            );
        }
    }

    @Override public boolean isOnFire() { return false; }
    @Override protected boolean shouldBurn() { return false; }
    @Override public boolean isPickable() { return false; }
    @Override public boolean isInvulnerable() { return true; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (structureId != null) tag.putString("StructureId", structureId.toString());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("StructureId")) this.structureId = new ResourceLocation(tag.getString("StructureId"));
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    public ResourceLocation getStructureId() { return structureId; }

    @Override
    public void writeSpawnData(FriendlyByteBuf buf) {
        buf.writeBoolean(structureId != null);
        if (structureId != null) buf.writeResourceLocation(structureId);
    }

    @Override
    public void readSpawnData(FriendlyByteBuf buf) {
        this.structureId = buf.readBoolean() ? buf.readResourceLocation() : null;
    }
}
