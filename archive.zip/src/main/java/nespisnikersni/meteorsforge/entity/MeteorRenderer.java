package nespisnikersni.meteorsforge.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import nespisnikersni.meteorsforge.Meteorsforge;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.AABB;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.Objects;


public class MeteorRenderer extends EntityRenderer<MeteorEntity> {

    // Развёртка: 2 строки × 4 столбца (AA / AAAA)
    private static final int COLS = 4;
    private static final int ROWS = 2;

    // Индексы тайлов в сетке (col,row)
    private static final int UP_COL = 0,   UP_ROW = 0;
    private static final int DOWN_COL = 1, DOWN_ROW = 0;

    private static final int WEST_COL = 0,  WEST_ROW = 1;
    private static final int NORTH_COL = 1, NORTH_ROW = 1;
    private static final int EAST_COL = 2,  EAST_ROW = 1;
    private static final int SOUTH_COL = 3, SOUTH_ROW = 1;

    public MeteorRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.3f;
    }

    @Override
    protected int getBlockLightLevel(MeteorEntity entity, BlockPos pos) {
        return 15;
    }

    @Override
    public ResourceLocation getTextureLocation(MeteorEntity entity) {
        if(entity.structureId != null) {
            return new ResourceLocation(Meteorsforge.MODID, "textures/entity/" + entity.structureId.getPath() + ".png");
        } else {
            return new ResourceLocation(Meteorsforge.MODID, "");
        }
    }

    @Override
    public void render(MeteorEntity entity, float entityYaw, float partialTicks,
                       PoseStack pose, MultiBufferSource buffers, int packedLight) {

        pose.pushPose();

        // Повернём куб в сторону yaw (по желанию)
        pose.mulPose(Axis.YP.rotationDegrees(entityYaw));

        // Масштаб куба (по умолчанию 1×1×1 блок)
        float half = 0.5f; // половина ребра

        Matrix4f mat = pose.last().pose();
        Matrix3f nrm = pose.last().normal();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));

        // ---- Геометрия куба (ось Y — вверх) ----
        // Координаты вершин
        float x0 = -half, x1 = half;
        float y0 = -half, y1 = half;
        float z0 = -half, z1 = half;

        // ===== Верх (UP) — плоскость Y = y1, нормаль (0,1,0)
        UV up = tileUV(UP_COL, UP_ROW);
        quad(vc, mat, nrm,
                x0, y1, z1,  up.u0, up.v1,  0, 1, 0, packedLight, 255,255,255,255,  // v0: NW
                x1, y1, z1,  up.u1, up.v1,  0, 1, 0, packedLight, 255,255,255,255,  // v1: NE
                x1, y1, z0,  up.u1, up.v0,  0, 1, 0, packedLight, 255,255,255,255,  // v2: SE
                x0, y1, z0,  up.u0, up.v0,  0, 1, 0, packedLight, 255,255,255,255); // v3: SW

        // ===== Низ (DOWN) — плоскость Y = y0, нормаль (0,-1,0)
        UV down = tileUV(DOWN_COL, DOWN_ROW);
        quad(vc, mat, nrm,
                x0, y0, z0,  down.u0, down.v1,  0,-1, 0, packedLight, 255,255,255,255, // SW
                x1, y0, z0,  down.u1, down.v1,  0,-1, 0, packedLight, 255,255,255,255, // SE
                x1, y0, z1,  down.u1, down.v0,  0,-1, 0, packedLight, 255,255,255,255, // NE
                x0, y0, z1,  down.u0, down.v0,  0,-1, 0, packedLight, 255,255,255,255);// NW

        // ===== Север (NORTH) — плоскость Z = z0, нормаль (0,0,-1)
        UV north = tileUV(NORTH_COL, NORTH_ROW);
        quad(vc, mat, nrm,
                x1, y0, z0,  north.u1, north.v1,  0, 0,-1, packedLight, 255,255,255,255, // SE
                x1, y1, z0,  north.u1, north.v0,  0, 0,-1, packedLight, 255,255,255,255, // NE
                x0, y1, z0,  north.u0, north.v0,  0, 0,-1, packedLight, 255,255,255,255, // NW
                x0, y0, z0,  north.u0, north.v1,  0, 0,-1, packedLight, 255,255,255,255);// SW

        // ===== Юг (SOUTH) — плоскость Z = z1, нормаль (0,0,1)
        UV south = tileUV(SOUTH_COL, SOUTH_ROW);
        quad(vc, mat, nrm,
                x0, y0, z1,  south.u0, south.v1,  0, 0, 1, packedLight, 255,255,255,255, // SW
                x0, y1, z1,  south.u0, south.v0,  0, 0, 1, packedLight, 255,255,255,255, // NW
                x1, y1, z1,  south.u1, south.v0,  0, 0, 1, packedLight, 255,255,255,255, // NE
                x1, y0, z1,  south.u1, south.v1,  0, 0, 1, packedLight, 255,255,255,255);// SE

        // ===== Запад (WEST) — плоскость X = x0, нормаль (-1,0,0)
        UV west = tileUV(WEST_COL, WEST_ROW);
        quad(vc, mat, nrm,
                x0, y0, z0,  west.u1, west.v1, -1, 0, 0, packedLight, 255,255,255,255, // SW
                x0, y1, z0,  west.u1, west.v0, -1, 0, 0, packedLight, 255,255,255,255, // NW
                x0, y1, z1,  west.u0, west.v0, -1, 0, 0, packedLight, 255,255,255,255, // NE
                x0, y0, z1,  west.u0, west.v1, -1, 0, 0, packedLight, 255,255,255,255);// SE

        // ===== Восток (EAST) — плоскость X = x1, нормаль (1,0,0)
        UV east = tileUV(EAST_COL, EAST_ROW);
        quad(vc, mat, nrm,
                x1, y0, z1,  east.u1, east.v1,  1, 0, 0, packedLight, 255,255,255,255, // SE
                x1, y1, z1,  east.u1, east.v0,  1, 0, 0, packedLight, 255,255,255,255, // NE
                x1, y1, z0,  east.u0, east.v0,  1, 0, 0, packedLight, 255,255,255,255, // NW
                x1, y0, z0,  east.u0, east.v1,  1, 0, 0, packedLight, 255,255,255,255);// SW

        pose.popPose();

        super.render(entity, entityYaw, partialTicks, pose, buffers, packedLight);
    }

    // --------- helpers ---------

    /** Возвращает UV прямоугольник одной «клетки» из сетки COLS×ROWS */
    private UV tileUV(int col, int row) {
        float du = 1.0f / COLS;
        float dv = 1.0f / ROWS;
        float u0 = col * du;
        float v0 = row * dv;
        float u1 = u0 + du;
        float v1 = v0 + dv;
        return new UV(u0, v0, u1, v1);
    }

    /** Квад из 4 вершин (порядок — по часовой) */
    private void quad(VertexConsumer vc, Matrix4f mat, Matrix3f nrm,
                      float x0, float y0, float z0, float u0, float v0, float nx, float ny, float nz, int light,
                      int r, int g, int b, int a,
                      float x1, float y1, float z1, float u1, float v1, float nx1, float ny1, float nz1, int light1,
                      int r1, int g1, int b1, int a1,
                      float x2, float y2, float z2, float u2, float v2, float nx2, float ny2, float nz2, int light2,
                      int r2, int g2, int b2, int a2,
                      float x3, float y3, float z3, float u3, float v3, float nx3, float ny3, float nz3, int light3,
                      int r3, int g3, int b3, int a3) {

        // v0
        vc.vertex(mat, x0, y0, z0)
          .color(r, g, b, a)
          .uv(u0, v0)
          .overlayCoords(0, 10)
          .uv2(light)
          .normal(nrm, nx, ny, nz)
          .endVertex();

        // v1
        vc.vertex(mat, x1, y1, z1)
          .color(r1, g1, b1, a1)
          .uv(u1, v1)
          .overlayCoords(0, 10)
          .uv2(light1)
          .normal(nrm, nx1, ny1, nz1)
          .endVertex();

        // v2
        vc.vertex(mat, x2, y2, z2)
          .color(r2, g2, b2, a2)
          .uv(u2, v2)
          .overlayCoords(0, 10)
          .uv2(light2)
          .normal(nrm, nx2, ny2, nz2)
          .endVertex();

        // v3
        vc.vertex(mat, x3, y3, z3)
          .color(r3, g3, b3, a3)
          .uv(u3, v3)
          .overlayCoords(0, 10)
          .uv2(light3)
          .normal(nrm, nx3, ny3, nz3)
          .endVertex();
    }

    private record UV(float u0, float v0, float u1, float v1) {}
}