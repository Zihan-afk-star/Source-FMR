package nespisnikersni.meteorsforge.block;

import net.minecraft.core.registries.Registries;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

import static nespisnikersni.meteorsforge.item.ModItems.ITEMS;

public final class ModBlocks {
    public static final String MODID = "meteorsforge";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(Registries.BLOCK, MODID);

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
    }

    private static <T extends Block> RegistryObject<T> register(String name, Supplier<T> supplier) {
        RegistryObject<T> reg = BLOCKS.register(name, supplier);
        ITEMS.register(name, () -> new BlockItem(reg.get(), new Item.Properties()));
        return reg;
    }


    public static final RegistryObject<Block> FREZARITE_BLOCK = register("frezarite_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE)
                    .strength(5.0f, 6.0f).requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> KREKNORITE_BLOCK = register("kreknorite_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE)
                    .strength(5.5f, 6.0f).requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> METEORITE_BLOCK = register("meteorite_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY)
                    .strength(6.0f, 7.0f).requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> BLOCK_RED_GEM = register("block_red_gem",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED)
                    .strength(5.0f, 6.0f).requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> FREZARITE_ORE = register("frezarite_ore",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.of().mapColor(MapColor.STONE)
                    .strength(3.0f, 3.0f).requiresCorrectToolForDrops(), UniformInt.of(1, 3)));

    public static final RegistryObject<Block> KREKNORITE_ORE = register("kreknorite_ore",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.of().mapColor(MapColor.STONE)
                    .strength(3.0f, 3.0f).requiresCorrectToolForDrops(), UniformInt.of(1, 3)));

    public static final RegistryObject<Block> METEOR_ORE = register("meteor_ore",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.of().mapColor(MapColor.STONE)
                    .strength(3.5f, 3.0f).requiresCorrectToolForDrops(), UniformInt.of(1, 4)));

    // Технические блоки из списка
    public static final RegistryObject<Block> PROTECTED_LAND_TESTER = register("protected_land_tester",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .strength(2.0f, 3.0f)));

    public static final RegistryObject<Block> PROTECTED_LAND_TESTER_ACTIVE = register("protected_land_tester_active",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .strength(2.0f, 3.0f).lightLevel(s -> 8)));

//    public static final RegistryObject<Block> FREEZER = register("freezer",
//            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
//                    .strength(4.0f, 6.0f).requiresCorrectToolForDrops()));
}