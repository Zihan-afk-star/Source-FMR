package nespisnikersni.meteorsforge;

import com.mojang.logging.LogUtils;
import nespisnikersni.meteorsforge.block.ModBlocks;
import nespisnikersni.meteorsforge.config.KVConfig;
import nespisnikersni.meteorsforge.config.KVDefaults;
import nespisnikersni.meteorsforge.item.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

import static nespisnikersni.meteorsforge.block.ModBlocks.BLOCKS;
import static nespisnikersni.meteorsforge.entity.ModEntities.ENTITIES;
import static nespisnikersni.meteorsforge.item.ModItems.FREZARITE_INGOT;
import static nespisnikersni.meteorsforge.item.ModItems.ITEMS;

@Mod(Meteorsforge.MODID)
public class Meteorsforge {

    public static final String MODID = "meteorsforge";
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);
    public static final RegistryObject<CreativeModeTab> MOD_TAB =
            CREATIVE_MODE_TABS.register("all_items", () ->
                    CreativeModeTab.builder()
                            .title(Component.translatable("itemGroup." + MODID))
                            .icon(() -> new ItemStack(FREZARITE_INGOT.get()))
                            .displayItems((params, output) -> {
                                ITEMS.getEntries().stream()
                                        .map(RegistryObject::get)
                                        .forEach(item -> output.accept(new ItemStack(item)));

                                 BLOCKS.getEntries().stream()
                                        .map(RegistryObject::get)
                                        .forEach(block -> output.accept(new ItemStack(block)));
                            })
                            .build()
            );

    public Meteorsforge() {
        KVConfig.loadOrCreateWithDefaults(KVDefaults.defaults());
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        modEventBus.addListener(this::commonSetup);

        CREATIVE_MODE_TABS.register(modEventBus);

        MinecraftForge.EVENT_BUS.register(this);

        modEventBus.addListener(this::addCreative);
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        ENTITIES.register(modEventBus);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.COMMON_SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
    }

    // Add the example block item to the building blocks tab
    private void addCreative(BuildCreativeModeTabContentsEvent e) {
    }

    // You can use SubscribeEvent and let the Event Bus discover methods to call
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
    }

    // You can use EventBusSubscriber to automatically register all static methods in the class annotated with @SubscribeEvent
    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents {

        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
        }
    }
}
