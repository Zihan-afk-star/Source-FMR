package nespisnikersni.meteorsforge;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Mod.EventBusSubscriber(modid = Meteorsforge.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class Config {

    // ---------- SPEC ----------
    public static final ForgeConfigSpec COMMON_SPEC;

    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    // ---------- ARMOR: FREZARITE ----------


    static {
        // ---------------- ARMOR ----------------
        COMMON_SPEC = B.build();
    }

    private Config() {}

    @SubscribeEvent
    static void onLoad(final ModConfigEvent event) {

    }
}
