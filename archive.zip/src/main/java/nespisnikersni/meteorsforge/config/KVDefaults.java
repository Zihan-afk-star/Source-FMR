package nespisnikersni.meteorsforge.config;

import java.util.LinkedHashMap;
import java.util.Map;

public final class KVDefaults {
    private KVDefaults() {}

    public static Map<String, String> defaults() {
        Map<String, String> d = new LinkedHashMap<>();

        // armor frezarite
        d.put("armor.frezarite.enabled","true");
        d.put("armor.frezarite.durabilityMultiplier","37");
        d.put("armor.frezarite.protections","3,6,8,3");
        d.put("armor.frezarite.enchantability","15");
        d.put("armor.frezarite.toughness","3.0");
        d.put("armor.frezarite.knockbackResist","0.10");
        d.put("armor.frezarite.equipSound","minecraft:item.armor.equip_netherite");
        d.put("armor.frezarite.repairItem","minecraft:diamond");

        // armor kreknorite
        d.put("armor.kreknorite.enabled","true");
        d.put("armor.kreknorite.durabilityMultiplier","40");
        d.put("armor.kreknorite.protections","4,7,9,4");
        d.put("armor.kreknorite.enchantability","18");
        d.put("armor.kreknorite.toughness","3.5");
        d.put("armor.kreknorite.knockbackResist","0.15");
        d.put("armor.kreknorite.equipSound","minecraft:item.armor.equip_diamond");
        d.put("armor.kreknorite.repairItem","minecraft:netherite_ingot");

        // armor meteorite
        d.put("armor.meteorite.enabled","true");
        d.put("armor.meteorite.durabilityMultiplier","33");
        d.put("armor.meteorite.protections","3,6,8,3");
        d.put("armor.meteorite.enchantability","20");
        d.put("armor.meteorite.toughness","2.5");
        d.put("armor.meteorite.knockbackResist","0.0");
        d.put("armor.meteorite.equipSound","minecraft:item.armor.equip_iron");
        d.put("armor.meteorite.repairItem","minecraft:iron_ingot");

        // ---------- Tool tier defaults ----------
        d.put("tier.frezarite.level", "4");
        d.put("tier.frezarite.uses", "2031");
        d.put("tier.frezarite.speed", "9.0");
        d.put("tier.frezarite.attackBonus", "4.0");
        d.put("tier.frezarite.enchantability", "15");
        d.put("tier.frezarite.repairItem", "minecraft:diamond");

        d.put("tier.kreknorite.level", "4");
        d.put("tier.kreknorite.uses", "2342");
        d.put("tier.kreknorite.speed", "9.5");
        d.put("tier.kreknorite.attackBonus", "4.5");
        d.put("tier.kreknorite.enchantability", "18");
        d.put("tier.kreknorite.repairItem", "minecraft:netherite_ingot");

        d.put("tier.meteorite.level", "3");
        d.put("tier.meteorite.uses", "1796");
        d.put("tier.meteorite.speed", "8.0");
        d.put("tier.meteorite.attackBonus", "3.0");
        d.put("tier.meteorite.enchantability", "20");
        d.put("tier.meteorite.repairItem", "minecraft:iron_ingot");

        return d;
    }
}