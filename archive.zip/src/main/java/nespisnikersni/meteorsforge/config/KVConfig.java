package nespisnikersni.meteorsforge.config;

import net.minecraftforge.fml.loading.FMLPaths;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class KVConfig {
    private static final String FILE_NAME = "meteorsforge-items.properties";
    private static final Map<String, String> map = new LinkedHashMap<>();
    private static Path path;

    private KVConfig() {}

    public static void loadOrCreateWithDefaults(Map<String, String> defaults) {
        path = FMLPaths.CONFIGDIR.get().resolve(FILE_NAME);

        map.clear();
        map.putAll(defaults);

        if (Files.exists(path)) {
            try (BufferedReader br = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#") || line.startsWith(";") || line.startsWith("//")) continue;
                    int eq = line.indexOf('=');
                    if (eq <= 0) continue;
                    String k = line.substring(0, eq).trim();
                    String v = line.substring(eq + 1).trim();
                    map.put(k, v);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                Files.createDirectories(path.getParent());
                try (BufferedWriter bw = Files.newBufferedWriter(path, StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                    for (var e : defaults.entrySet()) {
                        bw.write(e.getKey() + "=" + e.getValue());
                        bw.newLine();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String getString(String key, String def) {
        return map.getOrDefault(key, def);
    }

    public static boolean getBool(String key, boolean def) {
        String v = map.get(key);
        return v == null ? def : v.equalsIgnoreCase("true") || v.equalsIgnoreCase("yes") || v.equals("1");
    }

    public static int getInt(String key, int def) {
        try { return Integer.parseInt(map.get(key)); } catch (Exception e) { return def; }
    }

    public static double getDouble(String key, double def) {
        try { return Double.parseDouble(map.get(key)); } catch (Exception e) { return def; }
    }

    public static int[] getIntArray4(String key, int[] def) {
        String v = map.get(key);
        if (v == null) return def;
        String[] parts = v.split(",");
        if (parts.length != 4) return def;
        int[] arr = new int[4];
        try {
            for (int i = 0; i < 4; i++) arr[i] = Integer.parseInt(parts[i].trim());
            return arr;
        } catch (Exception e) { return def; }
    }
}